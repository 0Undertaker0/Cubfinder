package com.example.reservas20;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {
    @FormUrlEncoded
    @POST("reservar.php") // Asegúrate de que la URL coincida con la ubicación del archivo PHP
    Call<ResponseBody> realizarReserva(
            @Field("fecha") String fecha,
            @Field("hora") String hora,
            @Field("num_personas") int numPersonas
    );

    @FormUrlEncoded
    @POST("cubiculo.php") // Cambia esta ruta según tu configuración
    Call<ResponseBody> realizarReservaCubiculo(
            @Field("fecha") String fecha,
            @Field("tiempo_uso") int tiempoUso, // Asegúrate de que este nombre coincida en el PHP
            @Field("num_personas") int numPersonas // Consistente con la tabla de la base de datos
    );

    // Método para reservar un casillero
    @FormUrlEncoded
    @POST("reservar_casillero.php") // Asegúrate de que la URL coincida con la ubicación del archivo PHP
    Call<ResponseBody> realizarReservaCasillero(
            @Field("fecha") String fecha,
            @Field("tiempo_uso") int tiempoUso // Asegúrate de que este nombre coincida en el PHP
    );
}
